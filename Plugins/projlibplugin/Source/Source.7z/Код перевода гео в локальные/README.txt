ПРИМЕР НА UE С++

На макросы из Unreal Engine по типу UFUNCTION(BluePrintCallable, Category = "Coords Transformers") и UCLASS() и тд - не обращать внимание
FGEO_DOUBLE_STRUCT - String из UE. 

Файлы CoordsTransformer - обёртка с удобным интерфейсом библиотеки перевода гео в локальные
Файлы CoordsTransformersLibrary - пример использования библиотеки в Unreal Engine(чекайте скрин, изображены входные и выходные параметры)

Пример перевода  на питоне смотреть в папке Скрипты генерации траектории